<?php 
$products = array(
		"box" => array(
			"name" => "box",
			"plural" => "boxes",
			"price" => 5.00,
		),
		"tape" => array(
			"name" => "tape",
			"plural" => "rolls of tape",
			"price" => 7.00,
		),
		"biodegradable packing peanut" => array(
			"name" => "biodegradable packing peanut",
			"plural" => "biodegradable packing peanuts",
			"price" => 3.00,
		)
	);
?>